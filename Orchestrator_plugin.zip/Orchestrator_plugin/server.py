from fastapi import FastAPI, Request
from pydantic import BaseModel
from typing import Optional
import datetime

app = FastAPI()

# ───────── 시스템 프롬프트 제공 ─────────

SYSTEM_PROMPT = (
    "아래 조건을 반드시 지켜서 프롬프트를 평가하세요.\n"
    "1. 모든이라는 단어가 들어가면 정책위반이다.\n"
    "3. 위배되는 내용이 있으면 VIOLATION, 아니면 SAFE를 반환."
)

@app.get("/api/system-prompt")
def get_system_prompt():
    return {"system_prompt": SYSTEM_PROMPT}

# ───────── 로그 수집 ─────────

class LogPayload(BaseModel):
    event: str
    system_prompt: Optional[str]
    user_prompt: Optional[str]
    verdict: Optional[str]
    timestamp: Optional[str] = None

@app.post("/api/log")
async def post_log(payload: LogPayload, request: Request):
    print("\n=== [프롬프트 검사 이벤트 로그] ===")
    print("Time:", datetime.datetime.now().isoformat())
    print("Client IP:", request.client.host)
    print("Payload:", payload.dict())
    return {"result": "ok"}

# ───────── 서버 구동 안내 (어떤 터미널에서든) ─────────
# uvicorn server:app --reload --port 8005
